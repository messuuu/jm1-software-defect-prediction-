# 🔍 Software Defect Prediction using Machine Learning

> Predicting defect-prone NASA software modules using static code metrics — B.Tech Final Year Project, C.V. Raman Global University

[![Python](https://img.shields.io/badge/Python-3.8+-3776AB?style=flat&logo=python&logoColor=white)](https://python.org)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.3-F7931E?style=flat&logo=scikit-learn&logoColor=white)](https://scikit-learn.org)
[![XGBoost](https://img.shields.io/badge/XGBoost-2.0-brightgreen?style=flat)](https://xgboost.readthedocs.io)
[![SHAP](https://img.shields.io/badge/SHAP-Explainability-blueviolet?style=flat)](https://shap.readthedocs.io)
[![Dataset](https://img.shields.io/badge/Dataset-NASA%20JM1-orange?style=flat)](https://openml.org/d/1053)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat)](LICENSE)

---

## 📌 Overview

Software defects cost the industry billions of dollars annually. This project builds an **end-to-end Machine Learning pipeline** that predicts which software modules are likely to contain defects — *before testing even begins* — using only static code metrics.

The system is trained and evaluated on the **NASA JM1 dataset** (13,204 software modules from a real NASA project), handling a severe **84:16 class imbalance** using SMOTE, and explains predictions using **SHAP** values.

---

## 🎯 Problem Statement

Given 21 static code metrics of a software module (lines of code, cyclomatic complexity, Halstead metrics etc.), **predict whether the module will contain defects**.

- **Input:** 21 static code metrics per software module
- **Output:** Binary classification — Defective (1) or Non-defective (0)
- **Challenge:** Severe class imbalance — only 15.9% of modules are defective

---

## 📊 Results

### Model Comparison

| Model | Accuracy | Precision | Recall | F1 Score | ROC-AUC |
|-------|----------|-----------|--------|----------|---------|
| ✅ **Random Forest** *(Best F1)* | **82.92%** | **45.66%** | 37.53% | **0.4120** | **0.7903** |
| XGBoost *(Best Recall)* | 68.04% | 28.48% | **66.51%** | 0.3989 | 0.7314 |
| Logistic Regression | 69.06% | 27.60% | 57.96% | 0.3739 | 0.6766 |
| Decision Tree | 75.80% | 30.40% | 40.14% | 0.3460 | 0.6946 |

> All models trained with **SMOTE** oversampling · **5-fold stratified cross-validation** · 80/20 train-test split

### Cross-Validation Scores (5-Fold Stratified)

| Model | CV F1 Mean | CV F1 Std | Stability |
|-------|------------|-----------|-----------|
| Random Forest | 0.4372 | ±0.0189 | ✅ Best |
| XGBoost | 0.4031 | ±0.0116 | ✅ Stable |
| Logistic Regression | 0.3781 | ±0.0059 | Most consistent |
| Decision Tree | 0.3771 | ±0.0332 | Least stable |

### Key Findings

- 🏆 **Random Forest** achieves the best F1 Score (0.412) and Accuracy (82.9%)
- 🎯 **XGBoost** achieves the highest Recall (66.5%) — catches more real defects at cost of precision
- ⚖️ **SMOTE** effectively resolves the 84:16 class imbalance without data leakage (applied inside CV pipeline)
- 🔍 **SHAP** confirms `loc` (lines of code) and `branchCount` as the strongest defect predictors — consistent with McCabe's complexity theory
- 📐 Optimal decision **threshold tuned to 0.35** (instead of default 0.5) to improve recall for defect detection

---

## 🛠️ Tech Stack

| Category | Tools |
|----------|-------|
| Language | Python 3.8+ |
| ML Models | Scikit-learn, XGBoost |
| Imbalance Handling | imbalanced-learn (SMOTE) |
| Explainability | SHAP |
| Data | Pandas, NumPy |
| Visualization | Matplotlib, Seaborn |
| Tuning | GridSearchCV |
| Platform | Google Colab |

---

## 📁 Project Structure

```
jm1-software-defect-prediction/
│
├── 📓 notebook/
│   └── JM1_Defect_Prediction.ipynb   # Main notebook (18 cells, fully executed)
│
├── 📁 src/
│   └── jm1_defect_prediction.py      # Standalone Python source code
│
├── 📁 data/
│   └── README.md                     # Dataset download instructions
│
├── 📁 outputs/
│   └── figures/                      # All generated plots (PNG)
│       ├── fig1_class_distribution.png
│       ├── fig2_correlation_heatmap.png
│       ├── fig3_feature_correlation.png
│       ├── fig4_model_comparison.png
│       ├── fig5_roc_pr_curves.png
│       ├── fig6_confusion_threshold.png
│       ├── fig7_cross_validation.png
│       ├── fig8_learning_curves.png
│       ├── fig9_feature_importance.png
│       ├── fig10_shap_bar.png
│       └── fig11_shap_beeswarm.png
│
├── 📄 requirements.txt
├── 📄 .gitignore
└── 📄 README.md
```

---

## 🚀 How to Run

### Option A — Google Colab (Recommended, no setup needed)

1. Open the notebook directly in Colab:

   [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/YOUR_USERNAME/jm1-software-defect-prediction/blob/main/notebook/JM1_Defect_Prediction.ipynb)

2. Upload the dataset when prompted (see [data/README.md](data/README.md))
3. **Runtime → Run all**

### Option B — Local Python

**1. Clone the repository**
```bash
git clone https://github.com/YOUR_USERNAME/jm1-software-defect-prediction.git
cd jm1-software-defect-prediction
```

**2. Install dependencies**
```bash
pip install -r requirements.txt
```

**3. Download the dataset**

See [data/README.md](data/README.md) for instructions. Place the file at `data/jm1.csv`.

**4. Run**
```bash
python src/jm1_defect_prediction.py
```

---

## 📂 Dataset

**JM1 — NASA Metrics Data Program**

| Property | Value |
|----------|-------|
| Source | NASA KC1 Project (MDP) |
| Samples | 13,204 software modules |
| Features | 21 static code metrics |
| Target | `defects` (True/False) |
| Class ratio | 84.1% non-defective : 15.9% defective |
| Download | [OpenML #1053](https://openml.org/d/1053) |

### Features Used

**McCabe Complexity Metrics**
- `v(g)` — Cyclomatic complexity
- `ev(g)` — Essential complexity
- `iv(g)` — Design complexity
- `loc` — Lines of code
- `branchCount` — Branch count

**Halstead Software Science Metrics**
- `n`, `v`, `l`, `d`, `i`, `e`, `b`, `t` — Volume, difficulty, effort, etc.
- `uniq_Op`, `uniq_Opnd`, `total_Op`, `total_Opnd` — Operator/operand counts

**Line Count Metrics**
- `lOCode`, `lOComment`, `lOBlank`, `locCodeAndComment`

---

## 🧠 Methodology

```
JM1 Dataset (13,204 modules)
        │
        ▼
  Data Cleaning & EDA
  (type conversion, correlation analysis)
        │
        ▼
  80/20 Stratified Split
        │
        ▼
  SMOTE (training set only)          ← prevents data leakage
  84:16 → balanced
        │
        ▼
  ┌─────────────┬──────────────┬──────────────┬──────────┐
  │  Logistic   │  Decision    │    Random    │ XGBoost  │
  │ Regression  │    Tree      │    Forest    │          │
  └─────────────┴──────────────┴──────────────┴──────────┘
        │
        ▼
  GridSearchCV Hyperparameter Tuning (5-fold CV)
        │
        ▼
  Evaluation: F1, ROC-AUC, PR-AUC, Confusion Matrix
        │
        ▼
  SHAP Explainability + Threshold Optimisation
```

---

## 📈 Visualizations

<table>
  <tr>
    <td><img src="outputs/figures/fig1_class_distribution.png" width="380" alt="Class Distribution"/><br><sub>Class Distribution</sub></td>
    <td><img src="outputs/figures/fig4_model_comparison.png" width="380" alt="Model Comparison"/><br><sub>Model Comparison</sub></td>
  </tr>
  <tr>
    <td><img src="outputs/figures/fig5_roc_pr_curves.png" width="380" alt="ROC & PR Curves"/><br><sub>ROC & Precision-Recall Curves</sub></td>
    <td><img src="outputs/figures/fig10_shap_bar.png" width="380" alt="SHAP Feature Importance"/><br><sub>SHAP Feature Importance</sub></td>
  </tr>
</table>

---

## 💡 Why This Matters

| Without ML | With This System |
|------------|-----------------|
| Test all 13,204 modules | Focus on predicted high-risk modules |
| Defects found late in cycle | Flagged before testing starts |
| Manual code review of everything | Prioritised review of risky modules |
| No insight into why a module is risky | SHAP explains every prediction |

---

## 🔑 Notebook Contents (18 Cells)

| Cell | Description |
|------|-------------|
| 1 | Install dependencies |
| 2 | Import libraries |
| 3 | Load JM1 dataset (13,204 rows) |
| 4 | Data quality check — zero missing values |
| 5 | EDA — class distribution (bar + pie) |
| 6 | EDA — feature correlation heatmap |
| 7 | EDA — feature correlation with target |
| 8 | Stratified 80/20 train-test split |
| 9 | Train 4 models with SMOTE pipeline |
| 10 | Model comparison bar chart |
| 11 | ROC + Precision-Recall curves |
| 12 | Confusion matrix + threshold analysis |
| 13 | GridSearchCV hyperparameter tuning |
| 14 | SHAP explainability (bar + beeswarm) |
| 15 | Random Forest feature importance |
| 16 | Final summary table |
| 17 | 5-fold cross-validation comparison |
| 18 | Learning curves (overfitting check) |

---

## 📚 References

1. Breiman, L. "Random Forests." *Machine Learning*, 45(1), 2001.
2. Chen, T. & Guestrin, C. "XGBoost: A Scalable Tree Boosting System." *KDD*, 2016.
3. Chawla, N. et al. "SMOTE: Synthetic Minority Over-sampling Technique." *JAIR*, 2002.
4. Lundberg, S. & Lee, S. "A Unified Approach to Interpreting Model Predictions (SHAP)." *NeurIPS*, 2017.
5. Nagappan, N. et al. "Using Software Dependencies and Churn Metrics to Predict Field Failures." *ESEM*, 2007.
6. NASA Metrics Data Program — JM1 Dataset. Available at: https://openml.org/d/1053

---

## 👤 Author

**Rudra Prasad Sahu**
B.Tech Computer Science & Engineering
C.V. Raman Global University, Bhubaneswar

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-0A66C2?style=flat&logo=linkedin)](https://linkedin.com/in/YOUR_LINKEDIN)
[![GitHub](https://img.shields.io/badge/GitHub-Follow-181717?style=flat&logo=github)](https://github.com/YOUR_USERNAME)

---

## 📄 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

---

<p align="center">
  <sub>⭐ If this project helped you, please give it a star!</sub>
</p>
